package com.yourname.lasertag;

import org.bukkit.plugin.java.JavaPlugin;
import com.yourname.lasertag.commands.LazerPistolCommand;
import com.yourname.lasertag.commands.LazerAKCommand;
import com.yourname.lasertag.commands.LazerCrystalCommand;

public class LaserTagPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        getCommand("lazerPistol").setExecutor(new LazerPistolCommand(this));
        getCommand("lazerAK").setExecutor(new LazerAKCommand(this));
        getCommand("lazerCrystal").setExecutor(new LazerCrystalCommand(this));
        getServer().getPluginManager().registerEvents(new LaserTagListener(this), this);
    }

    @Override
    public void onDisable() {
        
    }
}
