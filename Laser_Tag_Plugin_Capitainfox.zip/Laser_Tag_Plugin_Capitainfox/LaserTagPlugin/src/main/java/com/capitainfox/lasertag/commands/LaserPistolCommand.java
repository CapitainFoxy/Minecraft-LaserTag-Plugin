package com.yourname.lasertag.commands;

import com.yourname.lasertag.LaserTagPlugin;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class LazerPistolCommand implements CommandExecutor {
    private final LaserTagPlugin plugin;

    public LazerPistolCommand(LaserTagPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        Player player = (Player) sender;
        ItemStack pistol = new ItemStack(Material.STICK);
        ItemMeta meta = pistol.getItemMeta();
        meta.setDisplayName("Laser Pistol");
        pistol.setItemMeta(meta);

        player.getInventory().addItem(pistol);
        player.sendMessage("You have received a Laser Pistol!");

        return true;
    }
}
