package com.yourname.lasertag.commands;

import com.yourname.lasertag.LaserTagPlugin;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.Location;
import org.bukkit.block.Block;

public class LazerCrystalCommand implements CommandExecutor {
    private final LaserTagPlugin plugin;

    public LazerCrystalCommand(LaserTagPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        Player player = (Player) sender;
        Location location = player.getLocation();
        Block block = location.getBlock();

        block.setType(Material.ENDER_CRYSTAL);

        player.sendMessage("A Laser Crystal has been placed!");

        return true;
    }
}
