package com.yourname.lasertag;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;
import java.util.Random;

public class LaserTagListener implements Listener {
    private final LaserTagPlugin plugin;
    private final Random random = new Random();

    public LaserTagListener(LaserTagPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (item.getType() == Material.STICK && item.getItemMeta().getDisplayName().equals("Laser Pistol")) {
            shootLaser(player, "lazerPistol");
        } else if (item.getType() == Material.BLAZE_ROD && item.getItemMeta().getDisplayName().equals("Laser AK")) {
            shootLaser(player, "lazerAK");
        }
    }

    private void shootLaser(Player player, String weaponType) {
        int ammo = plugin.getConfig().getInt("weapons." + weaponType + ".max_ammo");
        long reloadTime = plugin.getConfig().getLong("weapons." + weaponType + ".reload_time") * 20;
        long fireRate = plugin.getConfig().getLong("weapons." + weaponType + ".fire_rate") * 20;

        

        Snowball snowball = player.launchProjectile(Snowball.class);
        snowball.setCustomName(weaponType);
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Snowball && event.getEntity() instanceof Player) {
            Snowball snowball = (Snowball) event.getDamager();
            Player hitPlayer = (Player) event.getEntity();
            String weaponType = snowball.getCustomName();

            double damage = 0;
            if ("lazerPistol".equals(weaponType)) {
                damage = event.getEntity().getLocation().getY() > hitPlayer.getEyeLocation().getY() ? 4 : 2;
            } else if ("lazerAK".equals(weaponType)) {
                damage = event.getEntity().getLocation().getY() > hitPlayer.getEyeLocation().getY() ? 3 : 1;
            }

            hitPlayer.damage(damage);
        }
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        if (event.getEntity().getType() == EntityType.ENDER_CRYSTAL) {
            event.blockList().clear(); 
            event.setCancelled(true); 

            Player killer = (Player) event.getEntity().getLastDamageCause().getEntity();
            applyRandomEffects(killer);
        }
    }

    private void applyRandomEffects(Player player) {
        List<String> effects = plugin.getConfig().getStringList("crystal.effects");
        int duration = plugin.getConfig().getInt("crystal.effects_duration") * 20;

        for (int i = 0; i < 2; i++) {
            PotionEffectType effectType = PotionEffectType.getByName(effects.get(random.nextInt(effects.size())));
            player.addPotionEffect(new PotionEffect(effectType, duration, 1));
        }
    }
}
